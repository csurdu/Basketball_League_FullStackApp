import React from 'react';

function CreateTeam() {
    return (
        <div>
            <h1>Create Team</h1>
            <p>Form a new team with available players.</p>
        </div>
    );
}

export default CreateTeam;
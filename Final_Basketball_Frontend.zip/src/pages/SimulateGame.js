import React from 'react';

function SimulateGame() {
    return (
        <div>
            <h1>Simulate Game</h1>
            <p>Simulate a match between two teams.</p>
        </div>
    );
}

export default SimulateGame;
import React from 'react';

function Teams() {
    return (
        <div>
            <h1>Teams</h1>
            <p>View and filter all teams.</p>
        </div>
    );
}

export default Teams;